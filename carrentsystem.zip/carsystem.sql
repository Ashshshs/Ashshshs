/*
 Navicat Premium Data Transfer

 Source Server         : 嘿嘿
 Source Server Type    : MySQL
 Source Server Version : 80029
 Source Host           : localhost:3306
 Source Schema         : carsystem

 Target Server Type    : MySQL
 Target Server Version : 80029
 File Encoding         : 65001

 Date: 17/06/2022 20:21:53
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for car
-- ----------------------------
DROP TABLE IF EXISTS `car`;
CREATE TABLE `car`  (
  `carid` int NOT NULL AUTO_INCREMENT,
  `carnumber` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `carbrand` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cartype` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `carcolor` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `cardayprice` int NOT NULL,
  `cardescribe` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `carimg` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `carstatus` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '未租',
  `carsubscribe` varchar(20) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '未预约',
  PRIMARY KEY (`carid`) USING BTREE,
  UNIQUE INDEX `carnum`(`carnumber`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 5 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of car
-- ----------------------------
INSERT INTO `car` VALUES (1, '渝A11111', '宝马', 'SUV', '蓝色', 200, '空间大且新', '/static/tupian/car1.png', '未租', '未预约');
INSERT INTO `car` VALUES (2, '渝A22222', '奔驰', '轿车', '银色', 100, '新又好', '/static/tupian/car2.png', '未租', '未预约');

-- ----------------------------
-- Table structure for orderinfo
-- ----------------------------
DROP TABLE IF EXISTS `orderinfo`;
CREATE TABLE `orderinfo`  (
  `orderid` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  `orderusername` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `ordercarid` int NOT NULL,
  `orderdate` timestamp NOT NULL,
  `orderday` int NOT NULL,
  `orderexpire` timestamp NOT NULL,
  `ordercomplete` varchar(10) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '未完成',
  PRIMARY KEY (`orderid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orderinfo
-- ----------------------------
INSERT INTO `orderinfo` VALUES (0000000010, '123', 1, '2022-06-17 18:59:00', 1, '2022-06-17 16:59:00', '已完成');
INSERT INTO `orderinfo` VALUES (0000000011, '123', 1, '2022-06-17 19:01:38', 2, '2022-06-19 19:01:38', '已完成');
INSERT INTO `orderinfo` VALUES (0000000012, '123', 1, '2022-06-17 19:02:04', 2, '2022-06-19 19:02:04', '已完成');
INSERT INTO `orderinfo` VALUES (0000000013, '123', 1, '2022-06-17 19:04:47', 2, '2022-06-19 19:04:47', '已完成');
INSERT INTO `orderinfo` VALUES (0000000014, '123', 1, '2022-06-17 19:06:22', 2, '2022-06-19 19:06:22', '已完成');
INSERT INTO `orderinfo` VALUES (0000000015, '123', 1, '2022-06-17 19:07:15', 2, '2022-06-19 19:07:15', '已完成');
INSERT INTO `orderinfo` VALUES (0000000016, '123', 1, '2022-06-17 19:08:45', 2, '2022-06-19 19:08:45', '已完成');
INSERT INTO `orderinfo` VALUES (0000000017, '123', 1, '2022-06-17 15:09:31', 2, '2022-06-19 19:09:31', '已完成');
INSERT INTO `orderinfo` VALUES (0000000018, '123', 2, '2022-06-17 19:11:36', 2, '2022-06-19 19:11:36', '已完成');
INSERT INTO `orderinfo` VALUES (0000000019, '123', 1, '2022-06-17 19:13:06', 2, '2022-06-19 19:13:06', '已完成');
INSERT INTO `orderinfo` VALUES (0000000020, '123', 1, '2022-06-17 19:15:05', 2, '2022-06-19 19:15:05', '已完成');

-- ----------------------------
-- Table structure for subscribeinfo
-- ----------------------------
DROP TABLE IF EXISTS `subscribeinfo`;
CREATE TABLE `subscribeinfo`  (
  `subscribeid` int(10) UNSIGNED ZEROFILL NOT NULL AUTO_INCREMENT,
  `subscribeusername` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `subscribecarid` int NOT NULL,
  `subscribedate` timestamp NOT NULL,
  PRIMARY KEY (`subscribeid`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of subscribeinfo
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userpassword` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `userphone` varchar(11) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `useremail` varchar(40) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `usernickname` varchar(30) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `usersex` varchar(5) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `usermoney` decimal(10, 2) NULL DEFAULT 0.00,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username`) USING BTREE COMMENT '唯一的username'
) ENGINE = InnoDB AUTO_INCREMENT = 8 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES (1, '123', '123', '11111111111', '1', '黑铁', '男', 510.00);
INSERT INTO `user` VALUES (2, '123456', '123', 'heihei', 'heiheie', '青铜', '女', 1000.00);
INSERT INTO `user` VALUES (3, '12344', '123456', '123456789', '123456', '白银', '男', 1000.00);
INSERT INTO `user` VALUES (4, '12121', '12', '123123', '12312', '黄金', '女', 1000.00);
INSERT INTO `user` VALUES (10, '123456789', '123456789', '12345678909', '123456789@qq.com', NULL, NULL, 0.00);

SET FOREIGN_KEY_CHECKS = 1;
