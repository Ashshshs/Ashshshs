package com.car.dao;

import com.car.pojo.User;
import org.apache.ibatis.annotations.Param;

import java.math.BigDecimal;
import java.util.List;

public interface userMapper {
    List<User> selectAllUser();

    User loginUser(@Param("username") String username,@Param("userpassword") String userpassword);

    int resignUser(@Param("username") String username,@Param("userpassword") String userpassword,
                   @Param("userphone") String userphone,@Param("useremail") String useremail);

    int changeUser(@Param("username") String username,@Param("userpassword") String userpassword,
                   @Param("newuserpassword") String newuserpassword,
                   @Param("userphone") String userphone,@Param("useremail") String useremail);

    User forgetUser(@Param("userphone") String userphone,@Param("useremail") String useremail);

    int changeUserinfo(@Param("username") String username,@Param("usernickname") String usernickname,
                       @Param("userphone") String userphone,@Param("useremail") String useremail,
                        @Param("usersex") String usersex);

    User queryUserByname(@Param("username") String username);

    int giveDeposit(@Param("username") String username,@Param("deposit") BigDecimal deposit);

    int deleteUserByid(@Param("id") int id);

    int rechargemoney(@Param("id") int id,@Param("recharge") BigDecimal recharge);

}
