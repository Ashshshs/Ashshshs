package com.car.dao;

import com.car.pojo.Order;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public interface orderMapper {
    int addOrder(@Param("orderusername") String orderusername, @Param("ordercarid") int ordercarid,
                 @Param("orderdate") Timestamp orderdate, @Param("orderday") int orderday,
                 @Param("orderexpire") Timestamp orderexpire);

    List<Order> queryingOrderByUserName(@Param("orderusername") String orderusername);

    List<Order> queryOrderByUserName(@Param("orderusername") String orderusername);

    int deleteOrder(@Param("orderid") int orderid);

    List<Order> queryAllOrder();

    int completeOrder(@Param("orderid") int orderid);

    Order queryOrderByid(@Param("orderid") int orderid);
}
