package com.car.dao;

import com.car.pojo.Subscribe;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public interface subscribeMapper {
    int addSubscribe(@Param("subscribeusername") String subscribeusername, @Param("subscribecarid") int subscribecarid,
                 @Param("subscribedate") Timestamp subscribedate);

    List<Subscribe> querySubscribeByUserName(@Param("subscribeusername") String subscribeusername);

    int deleteSubscribe(@Param("subscribeid") int subscribeid);

}
