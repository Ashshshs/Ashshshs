package com.car.dao;


import com.car.pojo.Car;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface carMapper {
    List<Car> queryallCar();

    Car queryCarByid(@Param("carid") int carid);

    int updateCarstatus(@Param("carid") int carid);

    int updateCarstatus1(@Param("carid") int carid);

    int updateCarsubscribe(@Param("carid") int carid);

    int updateCarsubscribe1(@Param("carid") int carid);

    List<Car> queryCarBybrand(@Param("carbrand") String carbrand);

    int deleteCarByid(@Param("carid") int carid);
}
