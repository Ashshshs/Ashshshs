package com.car.pojo;

import java.sql.Timestamp;

public class Order {
    private int orderid;
    private String orderusername;
    private int ordercarid;

    private Timestamp orderdate;

    private int orderday;

    private Timestamp orderexpire;

    private String ordercomplete;
    public Order() {
    }

    public Order(int orderid, String orderusername, int ordercarid,
                 Timestamp orderdate, int orderday, Timestamp orderexpire,
                 String ordercomplete) {
        this.orderid = orderid;
        this.orderusername = orderusername;
        this.ordercarid = ordercarid;
        this.orderdate = orderdate;
        this.orderday = orderday;
        this.orderexpire = orderexpire;
        this.ordercomplete = ordercomplete;
    }

    public int getOrderid() {
        return orderid;
    }

    public void setOrderid(int orderid) {
        this.orderid = orderid;
    }

    public String getOrderusername() {
        return orderusername;
    }

    public void setOrderusername(String orderusername) {
        this.orderusername = orderusername;
    }

    public int getOrdercarid() {
        return ordercarid;
    }

    public void setOrdercarid(int ordercarid) {
        this.ordercarid = ordercarid;
    }

    public Timestamp getOrderdate() {
        return orderdate;
    }

    public void setOrderdate(Timestamp orderdate) {
        this.orderdate = orderdate;
    }

    public int getOrderday() {
        return orderday;
    }

    public void setOrderday(int orderday) {
        this.orderday = orderday;
    }

    public Timestamp getOrderexpire() {
        return orderexpire;
    }

    public void setOrderexpire(Timestamp orderexpire) {
        this.orderexpire = orderexpire;
    }

    public String getOrdercomplete() {
        return ordercomplete;
    }

    public void setOrdercomplete(String ordercomplete) {
        this.ordercomplete = ordercomplete;
    }

    @Override
    public String toString() {
        return "Order{" +
                "orderid=" + orderid +
                ", orderusername='" + orderusername + '\'' +
                ", ordercarid=" + ordercarid +
                ", orderdate=" + orderdate +
                ", orderday=" + orderday +
                ", orderexpire=" + orderexpire +
                ", ordercomplete='" + ordercomplete + '\'' +
                '}';
    }
}
