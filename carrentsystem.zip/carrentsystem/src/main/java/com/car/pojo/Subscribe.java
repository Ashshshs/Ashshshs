package com.car.pojo;

import java.sql.Date;
import java.sql.Timestamp;

public class Subscribe {
    private int subscribeid;
    private String subscribeusername;
    private int subscribecarid;
    private Timestamp subscribedate;

    public Subscribe() {
    }

    public Subscribe(int subscribeid, String subscribeusername, int subscribecarid, Timestamp subscribedate) {
        this.subscribeid = subscribeid;
        this.subscribeusername = subscribeusername;
        this.subscribecarid = subscribecarid;
        this.subscribedate = subscribedate;
    }

    public int getSubscribeid() {
        return subscribeid;
    }

    public void setSubscribeid(int subscribeid) {
        this.subscribeid = subscribeid;
    }

    public String getSubscribeusername() {
        return subscribeusername;
    }

    public void setSubscribeusername(String subscribeusername) {
        this.subscribeusername = subscribeusername;
    }

    public int getSubscribecarid() {
        return subscribecarid;
    }

    public void setSubscribecarid(int subscribecarid) {
        this.subscribecarid = subscribecarid;
    }

    public Timestamp getSubscribedate() {
        return subscribedate;
    }

    public void setSubscribedate(Timestamp subscribedate) {
        this.subscribedate = subscribedate;
    }

    @Override
    public String toString() {
        return "Subscribe{" +
                "subscribeid=" + subscribeid +
                ", subscribeusername='" + subscribeusername + '\'' +
                ", subscribecarid=" + subscribecarid +
                ", subscribedate=" + subscribedate +
                '}';
    }
}
