package com.car.pojo;

import java.math.BigDecimal;

public class User {
    private int id;
    private String username;
    private String userpassword;
    private String userphone;
    private String useremail;
    private String usernickname;
    private String usersex;
    private BigDecimal usermoney;
    public User() {
    }

    public User(int id, String username, String userpassword, String userphone,
                String useremail, String usernickname, String usersex, BigDecimal usermoney) {
        this.id = id;
        this.username = username;
        this.userpassword = userpassword;
        this.userphone = userphone;
        this.useremail = useremail;
        this.usernickname = usernickname;
        this.usersex = usersex;
        this.usermoney = usermoney;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUserpassword() {
        return userpassword;
    }

    public void setUserpassword(String userpassword) {
        this.userpassword = userpassword;
    }

    public String getUserphone() {
        return userphone;
    }

    public void setUserphone(String userphone) {
        this.userphone = userphone;
    }

    public String getUseremail() {
        return useremail;
    }

    public void setUseremail(String useremail) {
        this.useremail = useremail;
    }

    public String getUsernickname() {
        return usernickname;
    }

    public void setUsernickname(String usernickname) {
        this.usernickname = usernickname;
    }

    public String getUsersex() {
        return usersex;
    }

    public void setUsersex(String usersex) {
        this.usersex = usersex;
    }

    public BigDecimal getUsermoney() {
        return usermoney;
    }

    public void setUsermoney(BigDecimal usermoney) {
        this.usermoney = usermoney;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", username='" + username + '\'' +
                ", userpassword='" + userpassword + '\'' +
                ", userphone='" + userphone + '\'' +
                ", useremail='" + useremail + '\'' +
                ", usernickname='" + usernickname + '\'' +
                ", usersex='" + usersex + '\'' +
                ", usermoney=" + usermoney +
                '}';
    }
}
