package com.car.pojo;

public class Car {
    private int carid;
    private String carnumber;
    private String carbrand;
    private String cartype;
    private String carcolor;
    private int cardayprice;
    private String cardescribe;
    private String carimg;
    private String carstatus;
    private String carsubscribe;
    public Car() {
    }

    public Car(int carid, String carnumber, String carbrand,
               String cartype, String carcolor, int cardayprice,
               String cardescribe, String carimg, String carstatus, String carsubscribe) {
        this.carid = carid;
        this.carnumber = carnumber;
        this.carbrand = carbrand;
        this.cartype = cartype;
        this.carcolor = carcolor;
        this.cardayprice = cardayprice;
        this.cardescribe = cardescribe;
        this.carimg = carimg;
        this.carstatus = carstatus;
        this.carsubscribe = carsubscribe;
    }

    public int getCarid() {
        return carid;
    }

    public void setCarid(int carid) {
        this.carid = carid;
    }

    public String getCarnumber() {
        return carnumber;
    }

    public void setCarnumber(String carnumber) {
        this.carnumber = carnumber;
    }

    public String getCarbrand() {
        return carbrand;
    }

    public void setCarbrand(String carbrand) {
        this.carbrand = carbrand;
    }

    public String getCartype() {
        return cartype;
    }

    public void setCartype(String cartype) {
        this.cartype = cartype;
    }

    public String getCarcolor() {
        return carcolor;
    }

    public void setCarcolor(String carcolor) {
        this.carcolor = carcolor;
    }

    public int getCardayprice() {
        return cardayprice;
    }

    public void setCardayprice(int cardayprice) {
        this.cardayprice = cardayprice;
    }

    public String getCardescribe() {
        return cardescribe;
    }

    public void setCardescribe(String cardescribe) {
        this.cardescribe = cardescribe;
    }

    public String getCarimg() {
        return carimg;
    }

    public void setCarimg(String carimg) {
        this.carimg = carimg;
    }

    public String getCarstatus() {
        return carstatus;
    }

    public void setCarstatus(String carstatus) {
        this.carstatus = carstatus;
    }

    public String getCarsubscribe() {
        return carsubscribe;
    }

    public void setCarsubscribe(String carsubscribe) {
        this.carsubscribe = carsubscribe;
    }

    @Override
    public String toString() {
        return "Car{" +
                "carid=" + carid +
                ", carnumber='" + carnumber + '\'' +
                ", carbrand='" + carbrand + '\'' +
                ", cartype='" + cartype + '\'' +
                ", carcolor='" + carcolor + '\'' +
                ", cardayprice=" + cardayprice +
                ", cardescribe='" + cardescribe + '\'' +
                ", carimg='" + carimg + '\'' +
                ", carstatus='" + carstatus + '\'' +
                ", carsubscribe='" + carsubscribe + '\'' +
                '}';
    }
}
