package com.car.controll;

import com.car.pojo.Car;
import com.car.service.CarService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/car")
public class CarControll {
    @Autowired
    @Qualifier("CarServiceImpl")
    private CarService carService;


    @RequestMapping("/t1")
    public String carinfo(Model model){
        List<Car> cars = carService.queryallCar();
        for (Car car : cars) {
            System.out.println(car);
        }
        model.addAttribute("car",cars);
        return "carinfo";
    }

    @RequestMapping("/t2")
    public String torentCar(Model model,int carid){
        Car car = carService.queryCarByid(carid);
        if (car.getCarstatus().equals("已租")) {
            return "notorentcar";
        }
        model.addAttribute("car",car);
        return "rentcar";
    }

    @RequestMapping("/t3")
    public String tosubscribeCar(Model model,int carid){
        Car car = carService.queryCarByid(carid);
        if (car.getCarsubscribe().equals("已预约")||car.getCarstatus().equals("未租")) {
            model.addAttribute("car",car);
            return "notosubscribecar";
        }
        model.addAttribute("car",car);
        return "subscribecar";
    }

    @RequestMapping("/t4")
    public String queryCarBybrand(Model model,String carbrand){
        List<Car> cars = carService.queryCarBybrand(carbrand);
        if(cars.size()==0){
            model.addAttribute("error","未查到相应品牌车辆");
        }
        model.addAttribute("car",cars);
        return "querycarbybrand";
    }

    @RequestMapping("/root1")
    public String rootcarinfo(Model model){
        List<Car> cars = carService.queryallCar();
        for (Car car : cars) {
            System.out.println(car);
        }
        model.addAttribute("car",cars);
        return "rootcarinfo";
    }

    @RequestMapping("/root2")
    public String deleteCarByid(int carid){
        int i = carService.deleteCarByid(carid);
        return "redirect:/car/root1";
    }
}
