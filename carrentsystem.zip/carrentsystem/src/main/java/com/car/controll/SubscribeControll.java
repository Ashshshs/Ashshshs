package com.car.controll;

import com.car.pojo.Car;
import com.car.pojo.Order;
import com.car.pojo.Subscribe;
import com.car.service.CarService;
import com.car.service.orderService;
import com.car.service.subscribeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

@Controller
@RequestMapping("/subscribe")
public class SubscribeControll {
    @Autowired
    @Qualifier("SubscribeServiceImpl")
    private subscribeService subscribeService;

    @Autowired
    @Qualifier("CarServiceImpl")
    private CarService carService;

    @RequestMapping("/t1")
    public String subscribeOrder(HttpSession session, Model model, String subscribeusername, int subscribecarid, Timestamp subscribedate){
        int i = carService.updateCarsubscribe(subscribecarid);
        subscribedate=new Timestamp(System.currentTimeMillis());
        subscribeusername=(String)session.getAttribute("username");
        if(i>0){
            int j = subscribeService.addSubscribe(subscribeusername, subscribecarid, subscribedate);
            if(j>0){
                System.out.println("成功预约");
            }
            List<Car> cars = carService.queryallCar();
            model.addAttribute("car",cars);
            return "carinfo";
        }
        else {
            model.addAttribute("success","y");
            return "subscribecar";
        }
    }

    @RequestMapping("/t2")
    public String querypersonorder(HttpSession session,Model model){
        List<Subscribe> subscribes = subscribeService.querySubscribeByUserName((String) session.getAttribute("username"));
        model.addAttribute("subscribe",subscribes);
        System.out.println("成功显示订单");
        return "personsubscribe";
    }

    @RequestMapping("/t3")
    public String deleteOrder(HttpSession session,Model model,int subscribeid,int subscribecarid){
        int i = subscribeService.deleteSubscribe(subscribeid);
        if(i>0){
            int i1 = carService.updateCarsubscribe1(subscribecarid);
            if(i1>0){
                System.out.println("成功取消预约");
            }
        }
        return "redirect:/subscribe/t2";
    }
}
