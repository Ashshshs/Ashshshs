package com.car.controll;

import com.car.pojo.Car;
import com.car.pojo.Order;
import com.car.pojo.User;
import com.car.service.CarService;
import com.car.service.UserService;
import com.car.service.orderService;

import com.car.service.subscribeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

@Controller
@RequestMapping("/order")
public class OrderControll {
    @Autowired
    @Qualifier("OrderServiceImpl")
    private orderService orderService;

    @Autowired
    @Qualifier("CarServiceImpl")
    private CarService carService;


    @Autowired
    @Qualifier("UserServiceImpl")
    private UserService userService;


    @RequestMapping("/t1")
    public String createorder(HttpSession session, Model model, String orderusername, int ordercarid, Timestamp orderdate, int rentday, BigDecimal sumprice) throws ParseException {
        String username = (String) session.getAttribute("username");
        User user = userService.queryUserByname(username);
        if (user.getUsermoney().compareTo(sumprice) >= 0) {
            carService.updateCarstatus(ordercarid);
            int i = userService.giveDeposit(username, sumprice);
            int orderday = rentday;
            long l = System.currentTimeMillis();
            orderdate = new Timestamp(l);
            Timestamp orderexpire = new Timestamp(l + 1000L * 60 * 60 * rentday * 24);
            orderusername = username;
            if (i > 0) {
                int j = orderService.addOrder(orderusername, ordercarid, orderdate, orderday, orderexpire);
                if (j > 0) {
                    System.out.println("成功租用");
                }
                List<Car> cars = carService.queryallCar();
                model.addAttribute("car", cars);
                return "carinfo";
            } else {
                model.addAttribute("success", "y");
                return "norentcar";
            }

        } else {
            model.addAttribute("success", "y");
            return "norentcar";
        }
    }

    @RequestMapping("/t2")
    public String queryingpersonorder(HttpSession session, Model model) {
        List<Order> allOrder = orderService.queryAllOrder();
        for (Order order : allOrder) {
            Timestamp orderexpire = order.getOrderexpire();
            if (orderexpire.compareTo(new Timestamp(System.currentTimeMillis())) <= 0) {
                if (order.getOrdercomplete().equals("未完成")) {
                    carService.updateCarstatus1(order.getOrdercarid());
                    int i = orderService.completeOrder(order.getOrderid());
                    Car car = carService.queryCarByid(order.getOrdercarid());
                    BigDecimal money = new BigDecimal(car.getCardayprice() * order.getOrderday() * 0.9);
                    userService.giveDeposit(order.getOrderusername(), money);
                }
            }
        }
        List<Order> orders = orderService.queryingOrderByUserName((String) session.getAttribute("username"));
        model.addAttribute("order", orders);
        System.out.println("成功显示订单");
        return "personorder";
    }

    @RequestMapping("/t3")
    public String deleteOrder(HttpSession session, Model model, int orderid, int ordercarid) {
        int i = orderService.completeOrder(orderid);
        Order order = orderService.queryOrderByid(orderid);
        Timestamp now = new Timestamp(System.currentTimeMillis());
        Timestamp old = order.getOrderdate();
        long use = now.getTime()-old.getTime() ;
        System.out.println("========>use:"+use);
        int x = (int) Math.ceil((double) use / 86400000);
        System.out.println("========>x:"+x);
        Car car = carService.queryCarByid(order.getOrdercarid());
        BigDecimal money = new BigDecimal(x * car.getCardayprice() * 0.9);
        System.out.println("========>money:"+money);
        userService.giveDeposit((String) session.getAttribute("username"), money);
        if (i > 0) {
            int i1 = carService.updateCarstatus1(ordercarid);
            if (i1 > 0) {
                System.out.println("成功完成订单");
            }

        }
        return "redirect:/order/t2";
    }

    @RequestMapping("/t4")
    public String querypersonorder(HttpSession session, Model model) {
        List<Order> allOrder = orderService.queryAllOrder();
        for (Order order : allOrder) {
            Timestamp orderexpire = order.getOrderexpire();
            if (orderexpire.compareTo(new Timestamp(System.currentTimeMillis())) <= 0) {
                if (order.getOrdercomplete().equals("未完成")) {
                    carService.updateCarstatus1(order.getOrdercarid());
                    int i = orderService.completeOrder(order.getOrderid());
                    Car car = carService.queryCarByid(order.getOrdercarid());
                    BigDecimal money = new BigDecimal(car.getCardayprice() * order.getOrderday() * 0.9);
                    userService.giveDeposit(order.getOrderusername(), money);
                }
            }
        }
        List<Order> orders = orderService.queryOrderByUserName((String) session.getAttribute("username"));
        model.addAttribute("order", orders);
        System.out.println("成功显示订单");
        return "personorderall";
    }

    @RequestMapping("/root1")
    public String manageOrder(Model model) {
        List<Order> allOrder = orderService.queryAllOrder();
        for (Order order : allOrder) {
            Timestamp orderexpire = order.getOrderexpire();
            if (orderexpire.compareTo(new Timestamp(System.currentTimeMillis())) <= 0) {
                if (order.getOrdercomplete().equals("未完成")) {
                    carService.updateCarstatus1(order.getOrdercarid());
                    int i = orderService.completeOrder(order.getOrderid());
                    Car car = carService.queryCarByid(order.getOrdercarid());
                    BigDecimal money = new BigDecimal(car.getCardayprice() * order.getOrderday() * 0.9);
                    userService.giveDeposit(order.getOrderusername(), money);
                }
            }
        }
        List<Order> orders = orderService.queryAllOrder();
        model.addAttribute("order", orders);
        return "rootorderinfo";
    }

    @RequestMapping("/root2")
    public String deleterootOrder(Model model, int orderid, int ordercarid) {
        int i = orderService.deleteOrder(orderid);
        if (i > 0) {
            int i1 = carService.updateCarstatus1(ordercarid);
            if (i1 > 0) {
                System.out.println("成功删除订单");
            }

        }
        return "redirect:/order/root1";
    }


}
