package com.car.controll;

import com.car.pojo.User;
import com.car.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/user")
public class UserloginControll {
    @Autowired
    @Qualifier("UserServiceImpl")
    private UserService userService;


    @RequestMapping("/t1")
    public String tologin(){
        return "login";
    }
    @RequestMapping("/t2")//确定登录是否成功
    public String loginUser(HttpSession session, Model model, String username, String userpassword) {
        if(username.equals("root") &&  userpassword.equals("root")){
            session.setAttribute("usernickname","root");
            return "redirect:/order/root1";
        }
        else {
            User user = userService.loginUser(username, userpassword);
            System.out.println(user);
            if (user != null) {
                /*model.addAttribute("name", user.getUsername());*/
                System.out.println("成功");
                session.setAttribute("usernickname", user.getUsernickname());
                session.setAttribute("usersex", user.getUsersex());
                session.setAttribute("username", user.getUsername());
                session.setAttribute("userphone", user.getUserphone());
                session.setAttribute("useremail", user.getUseremail());
                return "userinfo";
            } else {
                model.addAttribute("success", "n");
                System.out.println("失败");
                return "login";
            }
        }
    }

    @RequestMapping("/t3")
    public String zhuce() {
        return "zhuce";
    }

    @RequestMapping("/t4")
    public String register(Model model,String username,String userpassword,String userphone,String useremail) {
        List<User> users = userService.selectAllUser();
        List<String> names = new ArrayList<String>();
        for (User user : users) {
            names.add(user.getUsername());
        }
        System.out.println(names);
        System.out.println(username);
        for (String name : names) {
            if (name.equals(username)) {
                model.addAttribute("ifsuccess","n");
                model.addAttribute("success", "注册失败,用户名已存在");
                return "ifregister";
            }
        }
        int i = userService.resignUser(username, userpassword, userphone, useremail);
        if(i>0) {
            model.addAttribute("ifsuccess","y");
            model.addAttribute("success", "注册成功!");
        }
        return "ifregister";
    }

    @RequestMapping("/t5")
    public String tochangepwd(){
        return "changepwd";
    }

    @RequestMapping("/t6")
    public String toforgetpwd(){
        return "forgetpwd";
    }

    @RequestMapping("/t7")
    public String changepwd(Model model,String username,String userpassword,String newuserpassword,String userphone,String useremail){
        int i = userService.changeUser(username, userpassword, newuserpassword,userphone, useremail);
        System.out.println(username+"|"+userpassword+"|"+newuserpassword+"|"+userphone+"|"+useremail);
        if(i>0) {
            model.addAttribute("ifsuccess","y");
            model.addAttribute("success", "更改密码成功!");
        }else {
            model.addAttribute("ifsuccess","n");
            model.addAttribute("success", "更改密码失败,信息错误");
            return "ifchange";
        }
        return "ifchange";
    }
    @RequestMapping("/t8")
    public String forgetpwd(Model model,String userphone,String useremail){
        User user = userService.forgetUser(userphone, useremail);
        if (user != null) {
            model.addAttribute("username", user.getUsername());
            model.addAttribute("userpassword",user.getUserpassword());
            model.addAttribute("ifsuccess","y");
            System.out.println("信息为:"+user.getUsername()+"|"+user.getUserpassword());
            return "iffoeget";
        } else {
            model.addAttribute("ifsuccess","n");
            model.addAttribute("success","电话或邮箱有误");
            return "iffoeget";
        }
    }

    @RequestMapping("/t9")
    public String qianduan(){
        return "userinfo";
    }

    @RequestMapping("/t10")
    public String tousercenter(){
        return "userinfo";
    }

    @RequestMapping("t11")
    public String tochangeuserinfo(){
        return "changeuserinfo";
    }

    @RequestMapping("t12")
    public String changeuserinfo(HttpSession session,String usernickname,String userphone,String useremail,String usersex){
        String username=(String) session.getAttribute("username");
        int i = userService.changeUserinfo(username, usernickname, userphone, useremail,usersex);
        if(i>0) {
            session.setAttribute("usernickname",usernickname);
            session.setAttribute("userphone",userphone);
            session.setAttribute("useremail",useremail);
            session.setAttribute("usersex",usersex);
            System.out.println("修改用户信息成功");
        }
        return "userinfo";
    }

    @RequestMapping("/t13")
    public String queryusermoney(HttpSession session,Model model){
        User user = userService.queryUserByname((String) session.getAttribute("username"));
        BigDecimal usermoney = user.getUsermoney();
        model.addAttribute("usermoney",usermoney);
        return "queryusermoney";
    }

    @RequestMapping("/root1")
    public String queryAllUser(Model model){
        List<User> users = userService.selectAllUser();
        model.addAttribute("user",users);
        return "rootuserinfo";
    }

    @RequestMapping("/root2")
    public String deleteUserByid(int id){
        int i = userService.deleteUserByid(id);
        return "redirect:/user/root1";
    }

    @RequestMapping("/root3")
    public String torechargemoney(Model model,int id,String username,String usernickname){
        model.addAttribute("id",id);
        model.addAttribute("username",username);
        model.addAttribute("usernickname",usernickname);
        return "rechargemoney";
    }

    @RequestMapping("/root4")
    public String rechargemoney(int id,BigDecimal recharge){
        int rechargemoney = userService.rechargemoney(id,recharge);
        return "redirect:/user/root1";
    }
}
