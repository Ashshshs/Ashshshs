package com.car.service;

import com.car.dao.subscribeMapper;
import com.car.pojo.Subscribe;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public class subscribeServiceImpl implements subscribeService {
    private subscribeMapper subscribeMapper;

    public void setSubscribeMapper(subscribeMapper subscribeMapper) {
        this.subscribeMapper = subscribeMapper;
    }

    @Override
    public int addSubscribe(String subscribeusername, int subscribecarid, Timestamp subscribedate) {
        return subscribeMapper.addSubscribe(subscribeusername, subscribecarid, subscribedate);
    }

    @Override
    public List<Subscribe> querySubscribeByUserName(String subscribeusername) {
        return subscribeMapper.querySubscribeByUserName(subscribeusername);
    }

    @Override
    public int deleteSubscribe(int subscribeid) {
        return subscribeMapper.deleteSubscribe(subscribeid);
    }


}
