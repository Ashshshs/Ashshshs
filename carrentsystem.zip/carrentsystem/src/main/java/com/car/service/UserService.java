package com.car.service;

import com.car.pojo.User;

import java.math.BigDecimal;
import java.util.List;

public interface UserService {
    List<User> selectAllUser();

    User loginUser(String username,String userpassword);

    int resignUser(String username,String userpassword,String userphone,String useremail);

    int changeUser(String username,String userpassword,String newuserpassword,String userphone,String useremail);

    User forgetUser(String userphone,String useremail);

    int changeUserinfo(String username,String usernickname,String userphone,String useremail,String usersex);

    User queryUserByname( String username);

    int giveDeposit(String username, BigDecimal deposit);

    int deleteUserByid(int id);

    int rechargemoney(int id,BigDecimal recharge);
}
