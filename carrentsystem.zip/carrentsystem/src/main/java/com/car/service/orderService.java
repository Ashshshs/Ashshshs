package com.car.service;

import com.car.pojo.Order;

import java.sql.Timestamp;
import java.util.List;

public interface orderService {
    int addOrder(String orderusername, int ordercarid, Timestamp orderdate, int orderday,Timestamp orderexpire);

    List<Order> queryingOrderByUserName(String orderusername);

    List<Order> queryOrderByUserName(String orderusername);

    int deleteOrder(int orderid);

    List<Order> queryAllOrder();

    int completeOrder(int orderid);

    Order queryOrderByid( int orderid);
}
