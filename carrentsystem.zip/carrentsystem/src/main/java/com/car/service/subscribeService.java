package com.car.service;

import com.car.pojo.Subscribe;
import org.apache.ibatis.annotations.Param;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public interface subscribeService {
    int addSubscribe(String subscribeusername, int subscribecarid, Timestamp subscribedate);

    List<Subscribe> querySubscribeByUserName(String subscribeusername);

    int deleteSubscribe(int subscribeid);

}
