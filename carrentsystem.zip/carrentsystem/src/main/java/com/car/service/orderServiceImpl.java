package com.car.service;

import com.car.dao.orderMapper;
import com.car.pojo.Order;

import java.sql.Date;
import java.sql.Timestamp;
import java.util.List;

public class orderServiceImpl implements orderService{
    private orderMapper orderMapper;

    public void setOrderMapper(com.car.dao.orderMapper orderMapper) {
        this.orderMapper = orderMapper;
    }

    @Override
    public int addOrder(String orderusername, int ordercarid, Timestamp orderdate, int orderday, Timestamp orderexpire) {
        return orderMapper.addOrder(orderusername, ordercarid, orderdate, orderday, orderexpire);
    }

    @Override
    public List<Order> queryingOrderByUserName(String orderusername) {
        return orderMapper.queryingOrderByUserName(orderusername);
    }

    @Override
    public List<Order> queryOrderByUserName(String orderusername) {
        return orderMapper.queryOrderByUserName(orderusername);
    }

    @Override
    public int deleteOrder(int orderid) {
        return orderMapper.deleteOrder(orderid);
    }

    @Override
    public List<Order> queryAllOrder() {
        return orderMapper.queryAllOrder();
    }

    @Override
    public int completeOrder(int orderid) {
        return orderMapper.completeOrder(orderid);
    }

    @Override
    public Order queryOrderByid(int orderid) {
        return orderMapper.queryOrderByid(orderid);
    }
}
