package com.car.service;

import com.car.pojo.Car;


import java.util.List;

public interface CarService {
    List<Car> queryallCar();

    Car  queryCarByid(int carid);

    int updateCarstatus(int carid);

    int updateCarstatus1(int carid);

    int updateCarsubscribe(int carid);

    int updateCarsubscribe1(int subscribecarid);

    List<Car> queryCarBybrand(String carbrand);

    int deleteCarByid( int carid);
}
