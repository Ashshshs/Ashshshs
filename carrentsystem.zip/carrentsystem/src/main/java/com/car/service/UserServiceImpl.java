package com.car.service;

import com.car.dao.userMapper;
import com.car.pojo.User;

import java.math.BigDecimal;
import java.util.List;

public class UserServiceImpl implements UserService {
    private userMapper userMapper;

    public void setUserMapper(userMapper userMapper) {
        this.userMapper = userMapper;
    }

    public List<User> selectAllUser() {
        return userMapper.selectAllUser();
    }

    public User loginUser(String username, String userpassword) {
        return userMapper.loginUser(username, userpassword);
    }

    public int resignUser(String username, String userpassword, String userphone, String useremail) {
        return userMapper.resignUser(username, userpassword, userphone, useremail);
    }

    public int changeUser(String username, String userpassword, String newuserpassword, String userphone, String useremail) {
        return userMapper.changeUser(username, userpassword, newuserpassword, userphone, useremail);
    }

    public User forgetUser(String userphone, String useremail) {
        return userMapper.forgetUser(userphone, useremail);
    }

    @Override
    public int changeUserinfo(String username, String usernickname, String userphone, String useremail, String usersex) {
        return userMapper.changeUserinfo(username, usernickname, userphone, useremail, usersex);
    }

    @Override
    public User queryUserByname(String username) {
        return userMapper.queryUserByname(username);
    }

    @Override
    public int giveDeposit(String username, BigDecimal deposit) {
        return userMapper.giveDeposit(username, deposit);
    }

    @Override
    public int deleteUserByid(int id) {
        return userMapper.deleteUserByid(id);
    }

    @Override
    public int rechargemoney(int id, BigDecimal recharge) {
        return userMapper.rechargemoney(id, recharge);
    }
}
