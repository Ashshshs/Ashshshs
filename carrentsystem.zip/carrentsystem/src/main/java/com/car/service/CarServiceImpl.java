package com.car.service;

import com.car.dao.carMapper;
import com.car.pojo.Car;

import java.util.List;

public class CarServiceImpl implements CarService{
    private carMapper carMapper;
    public void setCarMapper(carMapper carMapper) {
        this.carMapper = carMapper;
    }


    @Override
    public List<Car> queryallCar() {
        return carMapper.queryallCar();
    }

    @Override
    public Car queryCarByid(int carid){
        return carMapper.queryCarByid(carid);
    }

    @Override
    public int updateCarstatus(int carid) {
        return carMapper.updateCarstatus(carid);
    }

    @Override
    public int updateCarstatus1(int carid) {
        return carMapper.updateCarstatus1(carid);
    }

    @Override
    public int updateCarsubscribe(int carid) {
        return carMapper.updateCarsubscribe(carid);
    }

    @Override
    public int updateCarsubscribe1(int subscribecarid) {
        return carMapper.updateCarsubscribe1(subscribecarid);
    }

    @Override
    public List<Car> queryCarBybrand(String carbrand) {
        return carMapper.queryCarBybrand(carbrand);
    }

    @Override
    public int deleteCarByid(int carid) {
        return carMapper.deleteCarByid(carid);
    }
}
